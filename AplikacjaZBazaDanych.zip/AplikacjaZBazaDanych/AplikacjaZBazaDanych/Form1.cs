﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplikacjaZBazaDanych
{
    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            using (AdresyEntities bazaDanychAdresy = new AdresyEntities())
            {
                string s = "Lista osob:\n";
                foreach (Osoba o in bazaDanychAdresy.Osoby)
                    s += o.Imię + " " + o.Nazwisko + "(" + o.Wiek + ")\n";
                MessageBox.Show(s);
            }

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            using (AdresyEntities bazaDanychAdresy = new AdresyEntities())
            {
                string s = "Lista osob:\n";
                foreach (Osoba o in bazaDanychAdresy.Osoby)
                    s += o.Imię + " " + o.Nazwisko + "(" + o.Wiek + ")\n";
                MessageBox.Show(s);

                int noweId = bazaDanychAdresy.Osoby.Max(o => o.Id) + 1;
                Osoba nowaOsoba = new Osoba()
                {
                    Id = noweId,
                    Imię = "Antoni",
                    Nazwisko = "Macierewicz",
                    Wiek = 60,
                    Email = "antoni@smolensk.pl",
                    //  NumerTelefonu = 790000001
                };
                bazaDanychAdresy.Osoby.Add(nowaOsoba);
                bazaDanychAdresy.SaveChanges();

                s = "lista osob:\n";
                foreach (Osoba o in bazaDanychAdresy.Osoby)
                    s += o.Imię + " " + o.Nazwisko + "(" + o.Wiek + ")\n";
                MessageBox.Show(s);
                Form1_Load(null, null);
            }

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            using (AdresyEntities bazaDanychAdresy = new AdresyEntities())
            {
                var osobyPelnoletnie = from o in bazaDanychAdresy.Osoby where o.Wiek >= 18 orderby o.Nazwisko select o;

                string s = "Lista osob pełnoletnich: \n";
                foreach (Osoba o in osobyPelnoletnie)
                    s += o.Imię + " " + o.Nazwisko + "(" + o.Wiek + ")\n";
                MessageBox.Show(s);
                Form1_Load(null, null);
            }
        }

        AdresyEntities bazaDanychAdresy;
        bool daneZmienione;
        private async void Form1_Load(object sender, EventArgs e)
        {
            bazaDanychAdresy = new AdresyEntities();
            bazaDanychAdresy.Osoby.Load();
            dataGridView2.DataSource = bazaDanychAdresy.Osoby.Local.ToBindingList<Osoba>();
            dataGridView3.DataSource = bazaDanychAdresy.ListaOsobPelnoletnich();
            daneZmienione = false;
        }

        private void dataGridView2_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            daneZmienione = true;
        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!daneZmienione) return;
            switch (MessageBox.Show("Czy zapisać zmiany do bazy danych?", this.Text, MessageBoxButtons.YesNoCancel))
            {
                case DialogResult.Cancel:
                    e.Cancel = true;
                    break;
                case DialogResult.Yes:
                    try
                    {
                        this.Validate();
                        bazaDanychAdresy.SaveChanges();
                        bazaDanychAdresy.Dispose();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show("Zapisanie danychnie powiodło się(" + exc.Message + ")");
                    }
                    break;
                case DialogResult.No:
                    break;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bazaDanychAdresy.AktualizujWiek();
            Form1_Load(null, null);
        }

       
    }
}
        
    

